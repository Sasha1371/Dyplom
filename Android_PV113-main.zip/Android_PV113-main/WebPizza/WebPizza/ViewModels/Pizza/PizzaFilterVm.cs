﻿using WebPizza.ViewModels.Pagination;

namespace WebPizza.ViewModels.Pizza
{
    public class PizzaFilterVm : PaginationVm
    {
    }
}
