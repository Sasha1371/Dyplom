﻿namespace WebPizza.ViewModels.Pizza;

public class PizzaPhotoVm
{
    public string Name { get; set; } = null!;

    public int Priority { get; set; }
}

