﻿namespace WebPizza.ViewModels.Sizes
{
    public class SizeVm
    {
        public string Name { get; set; } = null!;
        public int Id { get; set; }
    }
}
