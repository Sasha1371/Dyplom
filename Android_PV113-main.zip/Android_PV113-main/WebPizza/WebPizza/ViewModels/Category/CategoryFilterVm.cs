﻿using WebPizza.ViewModels.Pagination;

namespace WebPizza.ViewModels.Category
{
    public class CategoryFilterVm : PaginationVm
    {
        public string? Name { get; set; }
    }
}
