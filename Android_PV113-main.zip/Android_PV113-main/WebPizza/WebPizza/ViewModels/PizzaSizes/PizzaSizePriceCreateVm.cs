﻿namespace WebPizza.ViewModels.PizzaSizes;

public class PizzaSizePriceCreateVm
{
    public int SizeId { get; set; }
    public decimal Price { get; set; }
}
