﻿namespace WebPizza.ViewModels.Account;

public class JwtTokenResponse
{
    public string Token { get; set; } = null!;
}
