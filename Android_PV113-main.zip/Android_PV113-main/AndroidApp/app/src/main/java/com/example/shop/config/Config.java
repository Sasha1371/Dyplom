package com.example.shop.config;

public class Config {
//    public static final String BASE_URL = "http://10.0.2.2:5174/";
//    public static final String BASE_URL = "http://192.168.50.18:5174/";
    public static final String BASE_URL = "https://android113.itstep.click/";
//    public static final String BASE_URL = "https://bomba.novakv.com/";
//    public static final String BASE_URL = "https://android.tohaproject.click/";
}
