package com.example.shop.category;

import com.example.shop.dto.CategoryItemDTO;

public interface OnCategoryClickListener {
    void onCategoryClick(CategoryItemDTO category);
}